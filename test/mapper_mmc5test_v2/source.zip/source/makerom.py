f = open('mmc5test_v2.nes', 'wb')

f.write(bytearray([ord('N'), ord('E'), ord('S'), 0x1A]))
f.write(bytearray([1, 1, 0x50, 0, 0, 0, 0, 0, 0, 0, 0, 0]))

prg = open('mmc5test_v2.prg', 'rb').read()
chr = open('mmc5test.chr', 'rb').read()

f.write(prg)
f.write(prg)
f.write(chr)
